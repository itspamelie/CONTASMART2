export default {
  extends: 'stylelint-config-standard-scss',
  rules: {
    'alpha-value-notation': null,
    'color-function-notation': null,
    'hue-degree-notation': null,
    'no-descending-specificity': null,
    'scss/no-global-function-names': null,
    'selector-not-notation': null
  }
}
