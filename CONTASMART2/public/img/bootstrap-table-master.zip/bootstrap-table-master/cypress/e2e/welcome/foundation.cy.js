require('../../common/welcome')('foundation')
