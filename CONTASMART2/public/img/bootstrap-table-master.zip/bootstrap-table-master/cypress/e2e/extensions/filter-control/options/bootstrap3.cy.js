require('../../../../extensions/filter-control/options')('bootstrap3')
